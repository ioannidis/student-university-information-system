package com.javaparttwo.service;

public class SecretaryService {
    // Not implemented
}
